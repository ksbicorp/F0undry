# F0undry KeyHacks Validation Framework
# API key validation methods based on KeyHacks repository

import requests
from typing import Dict, Any


class KeyHacksValidator:
    """Validate API keys using methods from keyhacks-master"""

    @staticmethod
    def validate_slack_webhook(url: str) -> Dict[str, Any]:
        """Validate Slack Webhook URL"""
        try:
            response = requests.post(
                url,
                json={"text": ""},
                headers={"Content-type": "application/json"},
                timeout=10
            )
            # 'missing_text_or_fallback_or_attachments' means valid
            if 'missing_text_or_fallback_or_attachments' in response.text:
                return {"valid": True, "status": "Valid Slack Webhook"}
            return {"valid": False, "status": response.text[:100]}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_slack_token(token: str) -> Dict[str, Any]:
        """Validate Slack API Token"""
        try:
            response = requests.post(
                "https://slack.com/api/auth.test",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10
            )
            data = response.json()
            if data.get('ok'):
                return {"valid": True, "status": f"Valid - Team: {data.get('team', 'N/A')}"}
            return {"valid": False, "status": data.get('error', 'Unknown error')}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_github_token(token: str) -> Dict[str, Any]:
        """Validate GitHub Token"""
        try:
            response = requests.get(
                "https://api.github.com/user",
                headers={"Authorization": f"token {token}"},
                timeout=10
            )
            if response.status_code == 200:
                data = response.json()
                return {"valid": True, "status": f"Valid - User: {data.get('login', 'N/A')}"}
            return {"valid": False, "status": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_google_api_key(key: str) -> Dict[str, Any]:
        """Validate Google API Key"""
        try:
            # Test with Maps API
            response = requests.get(
                f"https://maps.googleapis.com/maps/api/staticmap?center=45,10&zoom=7&size=400x400&key={key}",
                timeout=10
            )
            if response.status_code == 200:
                return {"valid": True, "status": "Valid Google API Key"}
            elif "API_KEY_INVALID" in response.text:
                return {"valid": False, "status": "Invalid API Key"}
            return {"valid": False, "status": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_stripe_api_key(key: str) -> Dict[str, Any]:
        """Validate Stripe API Key"""
        try:
            response = requests.get(
                "https://api.stripe.com/v1/charges",
                auth=(key, ''),
                timeout=10
            )
            if response.status_code == 200:
                return {"valid": True, "status": "Valid Stripe API Key"}
            elif response.status_code == 401:
                return {"valid": False, "status": "Invalid API Key"}
            return {"valid": False, "status": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_aws_access_key(access_key: str, secret_key: str = None) -> Dict[str, Any]:
        """Validate AWS Access Key (requires boto3)"""
        try:
            import boto3
            from botocore.exceptions import ClientError

            if not secret_key:
                return {"valid": False, "status": "Secret key required", "details": ""}

            client = boto3.client(
                'sts',
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key
            )
            response = client.get_caller_identity()
            return {"valid": True, "status": f"Valid - Account: {response['Account']}"}
        except ImportError:
            return {"valid": False, "status": "boto3 not installed", "details": "pip install boto3"}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_twilio_api_key(account_sid: str, auth_token: str) -> Dict[str, Any]:
        """Validate Twilio API Key"""
        try:
            response = requests.get(
                f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}.json",
                auth=(account_sid, auth_token),
                timeout=10
            )
            if response.status_code == 200:
                data = response.json()
                return {"valid": True, "status": f"Valid - {data.get('friendly_name', 'N/A')}"}
            return {"valid": False, "status": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_mailgun_api_key(key: str, domain: str = "samples.mailgun.org") -> Dict[str, Any]:
        """Validate Mailgun API Key"""
        try:
            response = requests.get(
                f"https://api.mailgun.net/v3/{domain}/stats",
                auth=("api", key),
                timeout=10
            )
            if response.status_code == 200:
                return {"valid": True, "status": "Valid Mailgun API Key"}
            return {"valid": False, "status": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_facebook_access_token(token: str) -> Dict[str, Any]:
        """Validate Facebook Access Token"""
        try:
            response = requests.get(
                "https://graph.facebook.com/me",
                params={"access_token": token},
                timeout=10
            )
            data = response.json()
            if 'id' in data:
                return {"valid": True, "status": f"Valid - User ID: {data['id']}"}
            return {"valid": False, "status": data.get('error', {}).get('message', 'Unknown error')}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}

    @staticmethod
    def validate_heroku_api_key(key: str) -> Dict[str, Any]:
        """Validate Heroku API Key"""
        try:
            response = requests.get(
                "https://api.heroku.com/account",
                headers={"Authorization": f"Bearer {key}"},
                timeout=10
            )
            if response.status_code == 200:
                data = response.json()
                return {"valid": True, "status": f"Valid - {data.get('email', 'N/A')}"}
            return {"valid": False, "status": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"valid": False, "status": f"Error: {str(e)}", "details": ""}


# API Type to Validator mapping
KEYHACKS_VALIDATORS = {
    'slack_webhook': KeyHacksValidator.validate_slack_webhook,
    'slack_token': KeyHacksValidator.validate_slack_token,
    'github_token': KeyHacksValidator.validate_github_token,
    'google_api': KeyHacksValidator.validate_google_api_key,
    'stripe_standard_api': KeyHacksValidator.validate_stripe_api_key,
    'aws_access_key': KeyHacksValidator.validate_aws_access_key,
    'twilio_api_key': KeyHacksValidator.validate_twilio_api_key,
    'mailgun_api_key': KeyHacksValidator.validate_mailgun_api_key,
    'facebook_access_token': KeyHacksValidator.validate_facebook_access_token,
    'heroku_api_key': KeyHacksValidator.validate_heroku_api_key,
}


def validate_key(key_type: str, key_value: str, **kwargs) -> Dict[str, Any]:
    """
    Validate an API key using KeyHacks methods

    Args:
        key_type: Type of API key (e.g., 'slack_token', 'github_token')
        key_value: The API key value
        **kwargs: Additional parameters needed for some validators

    Returns:
        Dict with 'valid', 'status', and optional 'details' keys
    """
    validator = KEYHACKS_VALIDATORS.get(key_type.lower())
    if not validator:
        return {"valid": False, "status": "Unsupported key type", "details": f"No validator for '{key_type}'"}

    try:
        return validator(key_value, **kwargs)
    except Exception as e:
        return {"valid": False, "status": "Validation error", "details": str(e)}
